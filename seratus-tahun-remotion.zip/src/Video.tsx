import React from 'react';
import {AbsoluteFill, Audio, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {SHOTS} from './data/shots';
import {ShotLayer} from './components/ShotLayer';
import {Embers} from './components/Embers';
import {Captions} from './components/Captions';
import {Overlays} from './components/Overlays';
import {Intro} from './components/Intro';
import {Outro} from './components/Outro';
import {HANDLE, GOLD_SOFT} from './config';
import {SANS} from './fonts';

export const Video: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;

  return (
    <AbsoluteFill style={{backgroundColor: '#05060a'}}>
      <Audio src={staticFile('audio/100abad.mp3')} />

      {SHOTS.map((shot, i) => (
        <ShotLayer key={`${shot.src}-${i}`} shot={shot} index={i} />
      ))}

      <Embers />

      {/* Vignette + gradasi bawah agar subtitle terbaca */}
      <AbsoluteFill
        style={{
          background:
            'radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 52%, rgba(0,0,0,0.6) 100%)',
        }}
      />
      <AbsoluteFill
        style={{
          background:
            'linear-gradient(to top, rgba(0,0,0,0.72) 0%, rgba(0,0,0,0.35) 22%, rgba(0,0,0,0) 40%)',
        }}
      />

      <Intro t={t} />
      <Overlays t={t} />
      <Captions t={t} />
      <Outro t={t} />

      {HANDLE ? (
        <div
          style={{
            position: 'absolute',
            top: 70,
            left: 0,
            right: 0,
            textAlign: 'center',
            fontFamily: SANS,
            fontWeight: 700,
            fontSize: 34,
            letterSpacing: 1,
            color: GOLD_SOFT,
            opacity: 0.85,
            textShadow: '0 2px 10px rgba(0,0,0,0.9)',
          }}
        >
          {HANDLE}
        </div>
      ) : null}
    </AbsoluteFill>
  );
};
