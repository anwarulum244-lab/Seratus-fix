// Pengaturan cepat. Ubah di sini lalu commit ulang.
export const FPS = 30;

// Isi handle akun untuk ditampilkan kecil di bagian atas video, contoh: '@namaakun'.
// Biarkan kosong kalau tidak ingin watermark.
export const HANDLE = '';

// Palet
export const GOLD = '#FFC76A';
export const GOLD_SOFT = '#FFE3B0';
export const IVORY = '#F6EBD3';
