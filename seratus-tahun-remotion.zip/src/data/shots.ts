// Urutan gambar (detik). Boleh diganti file di public/img/ atau diubah waktunya.
export type Shot = {src: string; start: number; end: number};
export const SHOTS: Shot[] = [
 {
  "src": "img/z18.jpg",
  "start": 0.0,
  "end": 2.18
 },
 {
  "src": "img/z11.jpg",
  "start": 2.18,
  "end": 8.4
 },
 {
  "src": "img/z32.jpg",
  "start": 8.4,
  "end": 12.31
 },
 {
  "src": "img/z20.jpg",
  "start": 12.31,
  "end": 19.55
 },
 {
  "src": "img/z11.jpg",
  "start": 19.55,
  "end": 22.85
 },
 {
  "src": "img/n08.jpg",
  "start": 22.85,
  "end": 29.27
 },
 {
  "src": "img/z01.jpg",
  "start": 29.27,
  "end": 34.91
 },
 {
  "src": "img/z02.jpg",
  "start": 34.91,
  "end": 39.01
 },
 {
  "src": "img/z31.jpg",
  "start": 39.01,
  "end": 43.13
 },
 {
  "src": "img/z39.jpg",
  "start": 43.13,
  "end": 49.24
 },
 {
  "src": "img/z33.jpg",
  "start": 49.24,
  "end": 54.32
 },
 {
  "src": "img/z40.jpg",
  "start": 54.32,
  "end": 59.48
 },
 {
  "src": "img/z10.jpg",
  "start": 59.48,
  "end": 63.55
 },
 {
  "src": "img/z30.jpg",
  "start": 63.55,
  "end": 68.96
 },
 {
  "src": "img/z26.jpg",
  "start": 68.96,
  "end": 72.69
 },
 {
  "src": "img/z03.jpg",
  "start": 72.69,
  "end": 74.69
 },
 {
  "src": "img/z12.jpg",
  "start": 74.69,
  "end": 79.2
 },
 {
  "src": "img/z13.jpg",
  "start": 79.2,
  "end": 81.97
 },
 {
  "src": "img/n17.jpg",
  "start": 81.97,
  "end": 85.98
 },
 {
  "src": "img/n15.jpg",
  "start": 85.98,
  "end": 88.69
 },
 {
  "src": "img/n16.jpg",
  "start": 88.69,
  "end": 91.62
 },
 {
  "src": "img/n14.jpg",
  "start": 91.62,
  "end": 95.02
 },
 {
  "src": "img/n13.jpg",
  "start": 95.02,
  "end": 98.0
 },
 {
  "src": "img/z08.jpg",
  "start": 98.0,
  "end": 101.29
 },
 {
  "src": "img/z09.jpg",
  "start": 101.29,
  "end": 104.85
 },
 {
  "src": "img/z22.jpg",
  "start": 104.85,
  "end": 109.67
 },
 {
  "src": "img/n12.jpg",
  "start": 109.67,
  "end": 112.35
 },
 {
  "src": "img/z24.jpg",
  "start": 112.35,
  "end": 115.5
 },
 {
  "src": "img/n11.jpg",
  "start": 115.5,
  "end": 119.4
 },
 {
  "src": "img/n06.jpg",
  "start": 119.4,
  "end": 123.13
 },
 {
  "src": "img/z28.jpg",
  "start": 123.13,
  "end": 126.0
 },
 {
  "src": "img/z11.jpg",
  "start": 126.0,
  "end": 131.64
 },
 {
  "src": "img/n05.jpg",
  "start": 131.64,
  "end": 136.5
 },
 {
  "src": "img/n01.jpg",
  "start": 136.5,
  "end": 139.85
 },
 {
  "src": "img/n03.jpg",
  "start": 139.85,
  "end": 143.61
 },
 {
  "src": "img/n09.jpg",
  "start": 143.61,
  "end": 147.98
 },
 {
  "src": "img/n10.jpg",
  "start": 147.98,
  "end": 151.09
 },
 {
  "src": "img/n04.jpg",
  "start": 151.09,
  "end": 157.74
 },
 {
  "src": "img/n07.jpg",
  "start": 157.74,
  "end": 165.12
 },
 {
  "src": "img/n02.jpg",
  "start": 165.12,
  "end": 168.5
 },
 {
  "src": "img/z37.jpg",
  "start": 168.5,
  "end": 171.53
 },
 {
  "src": "img/n18.jpg",
  "start": 171.53,
  "end": 174.42
 },
 {
  "src": "img/z21.jpg",
  "start": 174.42,
  "end": 181.35
 },
 {
  "src": "img/z29.jpg",
  "start": 181.35,
  "end": 185.42
 },
 {
  "src": "img/z04.jpg",
  "start": 185.42,
  "end": 188.31
 },
 {
  "src": "img/z07.jpg",
  "start": 188.31,
  "end": 191.21
 },
 {
  "src": "img/z16.jpg",
  "start": 191.21,
  "end": 196.58
 },
 {
  "src": "img/z27.jpg",
  "start": 196.58,
  "end": 200.28
 },
 {
  "src": "img/z04.jpg",
  "start": 200.28,
  "end": 202.19
 },
 {
  "src": "img/n12.jpg",
  "start": 202.19,
  "end": 207.61
 },
 {
  "src": "img/z32.jpg",
  "start": 207.61,
  "end": 217.05
 },
 {
  "src": "img/n08.jpg",
  "start": 217.05,
  "end": 222.41
 },
 {
  "src": "img/z40.jpg",
  "start": 222.41,
  "end": 228.28
 }
];
