// Semua waktu dalam detik, mengikuti voice-over 100abad.mp3.

export type YearCard = {at: number; dur: number; big: string; small: string};
export const YEAR_CARDS: YearCard[] = [
  {at: 29.5, dur: 4.2, big: '632', small: 'Madinah · wafatnya Nabi ﷺ'},
  {at: 63.8, dur: 4.6, big: '636', small: 'Pertempuran Yarmuk'},
  {at: 101.5, dur: 3.0, big: '661', small: 'Wafatnya Sayyidina Ali'},
  {at: 131.8, dur: 4.6, big: '711', small: 'Semenanjung Iberia'},
  {at: 158.0, dur: 4.8, big: '732', small: 'Tours–Poitiers'},
];

export type Banner = {at: number; dur: number; text: string; sub: string};
export const BANNERS: Banner[] = [
  {at: 49.5, dur: 4.0, text: 'PERANG RIDDAH', sub: 'Menyatukan kembali Jazirah Arab'},
  {at: 105.0, dur: 4.2, text: 'DINASTI UMAYYAH', sub: 'Damaskus sebagai pusat pemerintahan'},
];

export type NameTag = {at: number; dur: number; name: string; role: string};
export const NAME_TAGS: NameTag[] = [
  {at: 35.2, dur: 3.6, name: 'Abu Bakar ash-Shiddiq', role: 'Khalifah pertama'},
  {at: 54.5, dur: 4.0, name: 'Umar bin Khattab', role: 'Khalifah kedua'},
  {at: 79.4, dur: 3.8, name: 'Utsman bin Affan', role: 'Khalifah ketiga'},
  {at: 95.2, dur: 4.0, name: 'Ali bin Abi Thalib', role: 'Khalifah keempat'},
  {at: 105.3, dur: 4.2, name: 'Muawiyah bin Abi Sufyan', role: 'Pendiri Dinasti Umayyah'},
  {at: 115.8, dur: 3.4, name: 'Abdul Malik bin Marwan', role: 'Penguatan administrasi'},
  {at: 123.3, dur: 2.6, name: 'Al-Walid bin Abdul Malik', role: 'Puncak ekspansi'},
  {at: 137.5, dur: 5.0, name: 'Tariq bin Ziyad', role: 'bersama Musa bin Nushair'},
  {at: 148.0, dur: 3.0, name: 'Muhammad bin Qasim', role: 'Ekspedisi Sindh'},
  {at: 153.0, dur: 4.0, name: 'Qutayba bin Muslim', role: 'Ekspedisi Asia Tengah'},
];

// Pilihan jawaban pada pertanyaan penutup (muncul tepat saat disebut).
export const PILLS: {at: number; text: string}[] = [
  {at: 212.2, text: 'Kepemimpinan'},
  {at: 213.3, text: 'Perdagangan'},
  {at: 214.4, text: 'Dakwah'},
  {at: 215.3, text: 'Pertemuan Antarperadaban'},
];
export const PILLS_END = 217.0;

export const CTA = {at: 218.2, title: 'Tulis pendapatmu\ndi kolom komentar', sub: 'Usulkan topik kajian berikutnya'};
