// Dihasilkan dari penyelarasan naskah ke jeda suara 100abad.mp3 (detik).
// Boleh diedit manual kalau ada kalimat yang terasa kurang pas.
export type Clause = {start: number; end: number; text: string};
export const CLAUSES: Clause[] = [
 {
  "start": 0.0,
  "end": 2.18,
  "text": "100 TAHUN YANG MENGUBAH DUNIA"
 },
 {
  "start": 2.18,
  "end": 8.4,
  "text": "Perjalanan Perluasan Wilayah Islam, 632–732 M"
 },
 {
  "start": 8.4,
  "end": 12.31,
  "text": "Bayangkan sebuah kekuatan yang bermula dari Jazirah Arab,"
 },
 {
  "start": 12.31,
  "end": 14.71,
  "text": "kemudian dalam waktu sekitar satu abad,"
 },
 {
  "start": 14.71,
  "end": 19.55,
  "text": "wilayah kekuasaannya membentang dari perbatasan India hingga Semenanjung Iberia,"
 },
 {
  "start": 19.55,
  "end": 22.85,
  "text": "di wilayah yang sekarang dikenal sebagai Spanyol dan Portugal."
 },
 {
  "start": 22.85,
  "end": 24.52,
  "text": "Bagaimana semua ini terjadi?"
 },
 {
  "start": 24.52,
  "end": 29.27,
  "text": "Dan siapa saja pemimpin yang berada di balik perubahan besar dalam sejarah dunia?"
 },
 {
  "start": 29.27,
  "end": 34.91,
  "text": "Setelah wafatnya Nabi Muhammad ﷺ pada tahun 632 Masehi,"
 },
 {
  "start": 34.91,
  "end": 39.01,
  "text": "kepemimpinan umat Islam dilanjutkan oleh Sayyidina Abu Bakar ash-Shiddiq."
 },
 {
  "start": 39.01,
  "end": 41.02,
  "text": "Masa pemerintahannya relatif singkat,"
 },
 {
  "start": 41.02,
  "end": 43.13,
  "text": "hanya sekitar dua tahun. Namun,"
 },
 {
  "start": 43.13,
  "end": 49.24,
  "text": "ia menghadapi tantangan besar berupa pemberontakan dan lepasnya sejumlah suku Arab dari pemerintahan Madinah."
 },
 {
  "start": 49.24,
  "end": 54.32,
  "text": "Melalui Perang Riddah, Sayyidina Abu Bakar berupaya menyatukan kembali Jazirah Arab."
 },
 {
  "start": 54.32,
  "end": 56.27,
  "text": "Setelah Sayyidina Abu Bakar wafat,"
 },
 {
  "start": 56.27,
  "end": 59.48,
  "text": "kepemimpinan beralih kepada Sayyidina Umar bin Khattab."
 },
 {
  "start": 59.48,
  "end": 61.08,
  "text": "Pada masa Sayyidina Umar,"
 },
 {
  "start": 61.08,
  "end": 63.55,
  "text": "perluasan wilayah berlangsung sangat pesat."
 },
 {
  "start": 63.55,
  "end": 68.96,
  "text": "Pasukan Muslim mengalahkan Bizantium dalam Pertempuran Yarmuk pada tahun 636."
 },
 {
  "start": 68.96,
  "end": 72.69,
  "text": "Syam dan Palestina kemudian berada di bawah pemerintahan Islam."
 },
 {
  "start": 72.69,
  "end": 74.69,
  "text": "Mesir juga berhasil dikuasai,"
 },
 {
  "start": 74.69,
  "end": 79.2,
  "text": "sementara kekuasaan Dinasti Sasaniyah di Persia terus mengalami kemunduran."
 },
 {
  "start": 79.2,
  "end": 83.58,
  "text": "Berikutnya adalah Sayyidina Utsman bin Affan. Pada masa pemerintahannya,"
 },
 {
  "start": 83.58,
  "end": 85.98,
  "text": "ekspansi berlanjut ke berbagai kawasan,"
 },
 {
  "start": 85.98,
  "end": 88.69,
  "text": "termasuk wilayah Persia dan Afrika Utara."
 },
 {
  "start": 88.69,
  "end": 91.62,
  "text": "Kekuatan maritim umat Islam juga mulai berkembang."
 },
 {
  "start": 91.62,
  "end": 95.02,
  "text": "Namun, sejarah tidak selalu berjalan tanpa konflik."
 },
 {
  "start": 95.02,
  "end": 97.25,
  "text": "Pada masa Sayyidina Ali bin Abi Thalib,"
 },
 {
  "start": 97.25,
  "end": 101.29,
  "text": "umat Islam menghadapi perpecahan politik dan perang saudara yang mendalam."
 },
 {
  "start": 101.29,
  "end": 104.85,
  "text": "Setelah Sayyidina Ali wafat pada tahun 661,"
 },
 {
  "start": 104.85,
  "end": 109.67,
  "text": "Muawiyah bin Abi Sufyan mengambil alih kepemimpinan dan mendirikan Dinasti Umayyah,"
 },
 {
  "start": 109.67,
  "end": 112.35,
  "text": "dengan Damaskus sebagai pusat pemerintahannya."
 },
 {
  "start": 112.35,
  "end": 115.5,
  "text": "Di bawah Dinasti Umayyah, perluasan wilayah berlanjut."
 },
 {
  "start": 115.5,
  "end": 123.13,
  "text": "Abdul Malik bin Marwan memperkuat administrasi pemerintahan dan menjadikan bahasa Arab semakin dominan dalam birokrasi kekhalifahan."
 },
 {
  "start": 123.13,
  "end": 126.0,
  "text": "Kemudian datang masa Al-Walid bin Abdul Malik."
 },
 {
  "start": 126.0,
  "end": 131.64,
  "text": "Pada masa inilah ekspansi mencapai sejumlah wilayah yang sangat jauh dari pusat pemerintahan."
 },
 {
  "start": 131.64,
  "end": 137.33,
  "text": "Di bawah kepemimpinannya, pasukan Muslim memasuki Semenanjung Iberia pada tahun 711,"
 },
 {
  "start": 137.33,
  "end": 139.85,
  "text": "dipimpin oleh tokoh seperti Tariq bin Ziyad,"
 },
 {
  "start": 139.85,
  "end": 143.61,
  "text": "dalam rangkaian ekspedisi yang juga melibatkan Musa bin Nushair."
 },
 {
  "start": 143.61,
  "end": 146.27,
  "text": "Di sebelah timur, ekspansi menjangkau Sindh,"
 },
 {
  "start": 146.27,
  "end": 147.98,
  "text": "di kawasan Pakistan modern,"
 },
 {
  "start": 147.98,
  "end": 151.09,
  "text": "melalui ekspedisi yang dipimpin Muhammad bin Qasim."
 },
 {
  "start": 151.09,
  "end": 153.02,
  "text": "Sementara itu, di Asia Tengah,"
 },
 {
  "start": 153.02,
  "end": 157.74,
  "text": "ekspansi berlangsung melalui sejumlah kampanye yang melibatkan Qutayba bin Muslim."
 },
 {
  "start": 157.74,
  "end": 159.76,
  "text": "Pada tahun 732,"
 },
 {
  "start": 159.76,
  "end": 165.12,
  "text": "pasukan Umayyah berhadapan dengan pasukan Frank dalam pertempuran di kawasan Tours–Poitiers,"
 },
 {
  "start": 165.12,
  "end": 166.75,
  "text": "di wilayah Prancis modern."
 },
 {
  "start": 166.75,
  "end": 171.53,
  "text": "Peristiwa ini menjadi salah satu titik penting dalam sejarah ekspansi Islam di Eropa Barat."
 },
 {
  "start": 171.53,
  "end": 174.42,
  "text": "Namun, ada satu hal yang harus kita pahami."
 },
 {
  "start": 174.42,
  "end": 181.35,
  "text": "Meluasnya pemerintahan Islam tidak berarti seluruh penduduk wilayah tersebut langsung memeluk agama Islam."
 },
 {
  "start": 181.35,
  "end": 188.31,
  "text": "Di banyak tempat, proses Islamisasi berlangsung bertahap, melalui interaksi sosial, perdagangan, dakwah, perkawinan,"
 },
 {
  "start": 188.31,
  "end": 191.21,
  "text": "dan perubahan budaya selama beberapa generasi."
 },
 {
  "start": 191.21,
  "end": 196.58,
  "text": "Jadi, seratus tahun pertama ini bukan hanya kisah tentang peperangan dan pergantian pemimpin."
 },
 {
  "start": 196.58,
  "end": 202.19,
  "text": "Ini juga merupakan kisah tentang terbentuknya pemerintahan baru, pertemuan berbagai peradaban,"
 },
 {
  "start": 202.19,
  "end": 207.61,
  "text": "serta perjalanan panjang sebuah agama yang kemudian berkembang ke berbagai penjuru dunia."
 },
 {
  "start": 207.61,
  "end": 217.05,
  "text": "Menurut kalian, faktor apa yang paling berpengaruh dalam sejarah penyebaran Islam: kepemimpinan, perdagangan, dakwah, atau pertemuan antarperadaban?"
 },
 {
  "start": 217.05,
  "end": 219.42,
  "text": "Tuliskan pendapat kalian di kolom komentar."
 },
 {
  "start": 219.42,
  "end": 222.41,
  "text": "Jika ingin membahas sejarah Islam, ayat Al-Qur'an, hadis,"
 },
 {
  "start": 222.41,
  "end": 224.78,
  "text": "atau persoalan fikih lainnya,"
 },
 {
  "start": 224.78,
  "end": 228.28,
  "text": "silakan tuliskan topik yang ingin dikaji pada video berikutnya."
 }
];
