import {loadFont as loadPoppins} from '@remotion/google-fonts/Poppins';
import {loadFont as loadCinzel} from '@remotion/google-fonts/Cinzel';
import {loadFont as loadNaskh} from '@remotion/google-fonts/NotoNaskhArabic';

const poppins = loadPoppins('normal', {
  weights: ['600', '700', '800'],
  subsets: ['latin', 'latin-ext'],
}).fontFamily;

const cinzel = loadCinzel('normal', {
  weights: ['700', '800'],
  subsets: ['latin', 'latin-ext'],
}).fontFamily;

const naskh = loadNaskh('normal', {
  weights: ['700'],
  subsets: ['arabic'],
}).fontFamily;

// Naskh dipakai sebagai cadangan agar simbol ﷺ tampil benar.
export const SANS = `${poppins}, ${naskh}, 'Noto Sans Arabic', sans-serif`;
export const SERIF = `${cinzel}, ${naskh}, serif`;
