import React from 'react';
import {Easing, Img, Sequence, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import type {Shot} from '../data/shots';

const FADE = 8; // frame crossfade antar gambar

const Inner: React.FC<{shot: Shot; index: number; frames: number}> = ({shot, index, frames}) => {
  const frame = useCurrentFrame();
  const p = interpolate(frame, [0, Math.max(1, frames - 1)], [0, 1], {
    extrapolateRight: 'clamp',
    easing: Easing.inOut(Easing.quad),
  });

  // Empat pola gerak kamera bergantian
  const mode = index % 4;
  let scale = 1.1;
  let x = 0;
  let y = 0;
  if (mode === 0) scale = 1.04 + 0.13 * p; // zoom in
  if (mode === 1) scale = 1.17 - 0.12 * p; // zoom out
  if (mode === 2) {
    scale = 1.13;
    x = -34 + 68 * p; // geser kiri ke kanan
  }
  if (mode === 3) {
    scale = 1.13;
    y = 30 - 60 * p; // geser bawah ke atas
    x = 14 - 28 * p;
  }

  const fadeIn = index === 0 ? 1 : interpolate(frame, [0, FADE], [0, 1], {extrapolateRight: 'clamp'});

  return (
    <div style={{position: 'absolute', inset: 0, opacity: fadeIn, overflow: 'hidden'}}>
      <Img
        src={staticFile(shot.src)}
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          transform: `translate(${x}px, ${y}px) scale(${scale})`,
          transformOrigin: '50% 45%',
        }}
      />
    </div>
  );
};

export const ShotLayer: React.FC<{shot: Shot; index: number}> = ({shot, index}) => {
  const {fps} = useVideoConfig();
  const start = Math.round(shot.start * fps);
  const from = index === 0 ? 0 : Math.max(0, start - FADE);
  const to = Math.round(shot.end * fps);
  const frames = Math.max(1, to - from);
  return (
    <Sequence from={from} durationInFrames={frames} layout="none">
      <Inner shot={shot} index={index} frames={frames} />
    </Sequence>
  );
};
