import React from 'react';
import {CLAUSES} from '../data/timeline';
import {GOLD, IVORY} from '../config';
import {SANS} from '../fonts';
import {enterProgress} from './anim';

type Word = {w: string; s: number; e: number};
type Chunk = {start: number; end: number; showUntil: number; words: Word[]};

// Bobot durasi per kata (angka dan ﷺ dibacakan panjang di voice-over).
const weight = (w: string): number => {
  if (/^\d{3}$/.test(w)) return 22;
  if (w === 'ﷺ') return 26;
  const letters = w.replace(/[^\p{L}\p{N}]/gu, '').length;
  return letters + 1 + (/[,.?:]$/.test(w) ? 3 : 0);
};

const MAX_WORDS = 4;
const SKIP_BEFORE = 8.5; // judul pembuka tampil sebagai teks besar, bukan subtitle

const build = (): Chunk[] => {
  const out: Chunk[] = [];
  for (const c of CLAUSES) {
    if (c.end <= SKIP_BEFORE) continue;
    const words = c.text.split(/\s+/).filter(Boolean);
    const n = Math.max(1, Math.ceil(words.length / MAX_WORDS));
    const size = Math.ceil(words.length / n);
    const groups: string[][] = [];
    for (let i = 0; i < words.length; i += size) groups.push(words.slice(i, i + size));
    const totalW = words.reduce((a, w) => a + weight(w), 0);
    let cursor = c.start;
    for (const g of groups) {
      const ws: Word[] = [];
      const gStart = cursor;
      for (const w of g) {
        const d = ((c.end - c.start) * weight(w)) / totalW;
        ws.push({w, s: cursor, e: cursor + d});
        cursor += d;
      }
      out.push({start: gStart, end: cursor, showUntil: cursor, words: ws});
    }
  }
  // Tahan chunk sampai chunk berikutnya bila jedanya pendek.
  for (let i = 0; i < out.length; i++) {
    const next = out[i + 1];
    out[i].showUntil = next && next.start - out[i].end < 0.8 ? next.start : out[i].end + 0.25;
  }
  return out;
};

const CHUNKS = build();

export const Captions: React.FC<{t: number}> = ({t}) => {
  const chunk = CHUNKS.find((c) => t >= c.start && t < c.showUntil);
  if (!chunk) return null;
  const p = enterProgress(t, chunk.start, 0.18);
  return (
    <div
      style={{
        position: 'absolute',
        left: 70,
        right: 70,
        bottom: 430,
        display: 'flex',
        justifyContent: 'center',
        textAlign: 'center',
        fontFamily: SANS,
        fontWeight: 800,
        fontSize: 70,
        lineHeight: 1.22,
        flexWrap: 'wrap',
        gap: '0 20px',
        opacity: p,
        transform: `translateY(${(1 - p) * 16}px)`,
        textShadow: '0 4px 18px rgba(0,0,0,0.95), 0 0 4px rgba(0,0,0,0.95)',
      }}
    >
      {chunk.words.map((w, i) => {
        const active = t >= w.s && t < w.e;
        const spoken = t >= w.e;
        return (
          <span
            key={i}
            style={{
              color: active ? GOLD : IVORY,
              opacity: active || spoken ? 1 : 0.68,
            }}
          >
            {w.w}
          </span>
        );
      })}
    </div>
  );
};
