import {Easing, interpolate} from 'remotion';

/** Opacity 0..1 untuk jendela waktu [at, at+dur] dengan fade masuk/keluar (detik). */
export const windowOpacity = (t: number, at: number, dur: number, fadeIn = 0.35, fadeOut = 0.4): number => {
  if (t < at || t > at + dur) return 0;
  const a = interpolate(t, [at, at + fadeIn], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const b = interpolate(t, [at + dur - fadeOut, at + dur], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return Math.min(a, b);
};

/** Progres masuk 0..1 dengan easing keluar, untuk animasi pop/slide. */
export const enterProgress = (t: number, at: number, dur = 0.5): number =>
  interpolate(t, [at, at + dur], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.cubic),
  });
