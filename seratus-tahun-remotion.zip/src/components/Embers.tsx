import React from 'react';
import {AbsoluteFill, random, useCurrentFrame} from 'remotion';

const N = 30;
const H = 1920;

export const Embers: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{pointerEvents: 'none', mixBlendMode: 'screen'}}>
      {Array.from({length: N}).map((_, i) => {
        const x0 = random(`ex-${i}`) * 1080;
        const speed = 0.7 + random(`es-${i}`) * 1.4; // px per frame
        const size = 3 + random(`ez-${i}`) * 7;
        const phase = random(`ep-${i}`) * H;
        const sway = 18 + random(`ew-${i}`) * 40;
        const y = H + 40 - ((frame * speed + phase) % (H + 80));
        const x = x0 + Math.sin(frame / 38 + i) * sway;
        const flicker = 0.45 + 0.4 * Math.sin(frame / 7 + i * 2.1);
        const edge = Math.min(1, y / 260, (H - y) / 260);
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: x,
              top: y,
              width: size,
              height: size,
              borderRadius: '50%',
              background: 'radial-gradient(circle, #ffe2a0 0%, #ff9a3c 55%, rgba(255,120,30,0) 100%)',
              opacity: Math.max(0, flicker * edge) * 0.8,
              filter: 'blur(0.6px)',
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};
