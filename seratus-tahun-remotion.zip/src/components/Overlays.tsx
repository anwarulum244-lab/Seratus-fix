import React from 'react';
import {BANNERS, NAME_TAGS, YEAR_CARDS} from '../data/overlays';
import {GOLD, GOLD_SOFT, IVORY} from '../config';
import {SANS, SERIF} from '../fonts';
import {enterProgress, windowOpacity} from './anim';

const glow = '0 0 30px rgba(255,170,60,0.65), 0 6px 20px rgba(0,0,0,0.85)';

export const Overlays: React.FC<{t: number}> = ({t}) => {
  return (
    <>
      {YEAR_CARDS.map((c) => {
        const o = windowOpacity(t, c.at, c.dur, 0.4, 0.45);
        if (o <= 0) return null;
        const p = enterProgress(t, c.at, 0.6);
        return (
          <div
            key={`y-${c.at}`}
            style={{
              position: 'absolute',
              left: 40,
              right: 40,
              top: 170,
              textAlign: 'center',
              opacity: o,
              transform: `scale(${0.92 + 0.08 * p})`,
            }}
          >
            <div style={{fontFamily: SERIF, fontWeight: 800, fontSize: 250, lineHeight: 1, color: IVORY, textShadow: glow}}>
              {c.big}
            </div>
            <div
              style={{
                marginTop: 6,
                fontFamily: SANS,
                fontWeight: 700,
                fontSize: 46,
                letterSpacing: 2,
                color: GOLD_SOFT,
                textShadow: '0 4px 16px rgba(0,0,0,0.95)',
              }}
            >
              {c.small}
            </div>
          </div>
        );
      })}

      {BANNERS.map((b) => {
        const o = windowOpacity(t, b.at, b.dur, 0.35, 0.45);
        if (o <= 0) return null;
        const p = enterProgress(t, b.at, 0.55);
        const bar: React.CSSProperties = {
          height: 6,
          margin: '0 auto',
          width: 560 * p,
          background: 'linear-gradient(90deg, rgba(200,40,30,0), #d6392b, rgba(200,40,30,0))',
        };
        return (
          <div
            key={`b-${b.at}`}
            style={{position: 'absolute', left: 30, right: 30, top: 260, textAlign: 'center', opacity: o}}
          >
            <div style={bar} />
            <div
              style={{
                margin: '18px 0',
                fontFamily: SERIF,
                fontWeight: 800,
                fontSize: 104,
                letterSpacing: 4,
                lineHeight: 1.1,
                background: 'linear-gradient(#fff0cf, #f0b04c)',
                WebkitBackgroundClip: 'text',
                backgroundClip: 'text',
                color: 'transparent',
                filter: 'drop-shadow(0 6px 18px rgba(0,0,0,0.9))',
                transform: `scale(${0.95 + 0.05 * p})`,
              }}
            >
              {b.text}
            </div>
            <div style={bar} />
            <div
              style={{
                marginTop: 22,
                fontFamily: SANS,
                fontWeight: 600,
                fontSize: 40,
                color: GOLD_SOFT,
                textShadow: '0 4px 16px rgba(0,0,0,0.95)',
              }}
            >
              {b.sub}
            </div>
          </div>
        );
      })}

      {NAME_TAGS.map((n) => {
        const o = windowOpacity(t, n.at, n.dur, 0.35, 0.4);
        if (o <= 0) return null;
        const p = enterProgress(t, n.at, 0.5);
        return (
          <div
            key={`n-${n.at}`}
            style={{
              position: 'absolute',
              left: 80,
              right: 80,
              bottom: 760,
              display: 'flex',
              alignItems: 'stretch',
              gap: 22,
              opacity: o,
              transform: `translateX(${(1 - p) * -36}px)`,
            }}
          >
            <div style={{width: 7, borderRadius: 4, background: GOLD, boxShadow: '0 0 16px rgba(255,170,60,0.7)'}} />
            <div style={{textShadow: '0 4px 16px rgba(0,0,0,0.95)'}}>
              <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 56, color: IVORY, lineHeight: 1.15}}>{n.name}</div>
              <div style={{fontFamily: SANS, fontWeight: 600, fontSize: 36, color: GOLD, marginTop: 4}}>{n.role}</div>
            </div>
          </div>
        );
      })}
    </>
  );
};
