import React from 'react';
import {GOLD, GOLD_SOFT, IVORY} from '../config';
import {SANS, SERIF} from '../fonts';
import {enterProgress, windowOpacity} from './anim';

const glow = '0 0 34px rgba(255,170,60,0.65), 0 6px 22px rgba(0,0,0,0.85)';

export const Intro: React.FC<{t: number}> = ({t}) => {
  if (t > 8.5) return null;
  const t1 = windowOpacity(t, 0, 2.18, 0.25, 0.3);
  const sub = windowOpacity(t, 2.3, 6.0, 0.4, 0.5);
  const yrs = windowOpacity(t, 4.6, 3.7, 0.4, 0.5);
  const yp = enterProgress(t, 4.6, 0.6);
  return (
    <>
      <div
        style={{
          position: 'absolute',
          left: 40,
          right: 40,
          top: 640,
          textAlign: 'center',
          fontFamily: SERIF,
          fontWeight: 800,
          color: IVORY,
          opacity: t1,
          textShadow: glow,
          transform: `scale(${0.96 + 0.04 * enterProgress(t, 0, 0.5)})`,
        }}
      >
        <div style={{fontSize: 190, lineHeight: 1}}>100 TAHUN</div>
        <div style={{fontSize: 86, lineHeight: 1.25, letterSpacing: 2}}>YANG MENGUBAH DUNIA</div>
      </div>

      <div
        style={{
          position: 'absolute',
          left: 50,
          right: 50,
          top: 560,
          textAlign: 'center',
          fontFamily: SANS,
          fontWeight: 700,
          fontSize: 50,
          letterSpacing: 6,
          color: GOLD_SOFT,
          opacity: sub,
          textShadow: '0 4px 18px rgba(0,0,0,0.95)',
        }}
      >
        PERJALANAN PERLUASAN
        <br />
        WILAYAH ISLAM
      </div>

      <div
        style={{
          position: 'absolute',
          left: 40,
          right: 40,
          top: 800,
          textAlign: 'center',
          fontFamily: SERIF,
          fontWeight: 800,
          fontSize: 150,
          color: IVORY,
          opacity: yrs,
          transform: `scale(${0.94 + 0.06 * yp})`,
          textShadow: glow,
        }}
      >
        632 – 732 M
        <div
          style={{
            margin: '26px auto 0',
            width: 260,
            height: 5,
            borderRadius: 3,
            background: `linear-gradient(90deg, rgba(255,199,106,0), ${GOLD}, rgba(255,199,106,0))`,
          }}
        />
      </div>
    </>
  );
};
