import React from 'react';
import {CTA, PILLS, PILLS_END} from '../data/overlays';
import {GOLD, GOLD_SOFT, IVORY} from '../config';
import {SANS} from '../fonts';
import {enterProgress, windowOpacity} from './anim';

export const Outro: React.FC<{t: number}> = ({t}) => {
  const pillsOpacity = t >= PILLS[0].at && t < PILLS_END ? windowOpacity(t, PILLS[0].at, PILLS_END - PILLS[0].at, 0.01, 0.5) : 0;
  const ctaO = windowOpacity(t, CTA.at, 999, 0.5, 0.01);
  const pulse = 1 + 0.015 * Math.sin(t * 3.2);
  return (
    <>
      {pillsOpacity > 0 && (
        <div
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            top: 700,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: 24,
            opacity: pillsOpacity,
          }}
        >
          {PILLS.map((p) => {
            const e = enterProgress(t, p.at, 0.35);
            if (t < p.at) return null;
            return (
              <div
                key={p.text}
                style={{
                  padding: '22px 52px',
                  borderRadius: 70,
                  border: `3px solid ${GOLD}`,
                  background: 'rgba(8,8,10,0.55)',
                  color: IVORY,
                  fontFamily: SANS,
                  fontWeight: 700,
                  fontSize: 56,
                  boxShadow: '0 0 28px rgba(255,170,60,0.35)',
                  transform: `scale(${0.85 + 0.15 * e})`,
                  opacity: e,
                }}
              >
                {p.text}
              </div>
            );
          })}
        </div>
      )}

      {ctaO > 0 && (
        <div
          style={{
            position: 'absolute',
            left: 60,
            right: 60,
            top: 760,
            textAlign: 'center',
            opacity: ctaO,
            transform: `scale(${pulse})`,
            textShadow: '0 6px 24px rgba(0,0,0,0.95)',
          }}
        >
          <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 84, lineHeight: 1.18, color: IVORY, whiteSpace: 'pre-line'}}>
            {CTA.title}
          </div>
          <div style={{marginTop: 26, fontFamily: SANS, fontWeight: 600, fontSize: 44, color: GOLD_SOFT}}>{CTA.sub}</div>
        </div>
      )}
    </>
  );
};
