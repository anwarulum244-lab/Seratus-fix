import React from 'react';
import {Composition, staticFile} from 'remotion';
import {getAudioDurationInSeconds} from '@remotion/media-utils';
import {Video} from './Video';
import {FPS} from './config';

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="SeratusTahun"
      component={Video}
      width={1080}
      height={1920}
      fps={FPS}
      durationInFrames={6849}
      // Durasi video selalu mengikuti panjang MP3.
      calculateMetadata={async () => {
        const seconds = await getAudioDurationInSeconds(staticFile('audio/100abad.mp3'));
        return {durationInFrames: Math.ceil(seconds * FPS)};
      }}
    />
  );
};
