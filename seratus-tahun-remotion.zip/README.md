# 100 Tahun yang Mengubah Dunia (632–732 M)

Video Remotion 9:16 (1080x1920, 30 fps, H.264 + AAC). Durasi mengikuti `public/audio/100abad.mp3`.

## Render lewat GitHub
1. Buat repo baru di GitHub, lalu upload seluruh isi folder ini (atau `git push`) ke branch `main`.
2. Buka tab **Actions** → workflow **Render video** → **Run workflow**.
   (Setiap push ke `main` yang mengubah `src/` atau `public/` juga memicu render otomatis.)
3. Setelah selesai, buka run tersebut dan unduh artifact **100-tahun-mp4**.

## Render di komputer sendiri
```bash
npm install
npm run dev      # pratinjau di Remotion Studio
npm run render   # hasil: out/100-tahun.mp4
```

## Yang bisa diubah
- `src/data/shots.ts`: urutan gambar dan waktunya (detik). Gambar ada di `public/img/`.
- `src/data/overlays.ts`: kartu tahun, judul, nama tokoh, pilihan jawaban, ajakan komentar.
- `src/data/timeline.ts`: teks subtitle beserta waktunya.
- `src/config.ts`: `HANDLE` (watermark akun) dan warna.

Waktu subtitle dan gambar diselaraskan ke jeda napas pada `100abad.mp3`. Jika ada yang kurang pas,
cukup geser angka detiknya di file data di atas.

## Catatan
- Font (Poppins, Cinzel, Noto Naskh Arabic) diunduh dari Google Fonts saat render, jadi runner perlu internet.
- Kalau memakai voice-over lain, timeline di `src/data/` perlu disesuaikan.
